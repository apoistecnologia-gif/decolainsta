'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Plus,
  Instagram,
  Play,
  Pause,
  Trash2,
  Settings,
  Zap,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';
import { FadeIn, Stagger, StaggerItem, HoverLift } from '@/components/ui/animate';

const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  active: { label: 'Ativa', variant: 'default' },
  inactive: { label: 'Inativa', variant: 'secondary' },
  paused: { label: 'Pausada', variant: 'outline' },
  cooldown: { label: 'Cooldown', variant: 'destructive' },
  checkpoint: { label: 'Checkpoint', variant: 'destructive' },
  banned: { label: 'Banida', variant: 'destructive' },
};

export function AccountsList({ initialAccounts }: { initialAccounts: any[] }) {
  const [accounts, setAccounts] = useState(initialAccounts ?? []);
  const [showAdd, setShowAdd] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newProxy, setNewProxy] = useState('');
  const [adding, setAdding] = useState(false);

  const addAccount = async () => {
    if (!newUsername || !newPassword) {
      toast.error('Usuário e senha são obrigatórios');
      return;
    }
    setAdding(true);
    try {
      const res = await fetch('/api/instagram-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: newUsername.replace('@', '').trim(),
          password: newPassword,
          proxyUrl: newProxy || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data?.error ?? 'Erro ao adicionar conta');
        return;
      }
      toast.success('Conta adicionada com sucesso!');
      setAccounts((prev: any[]) => [data, ...(prev ?? [])]);
      setNewUsername('');
      setNewPassword('');
      setNewProxy('');
      setShowAdd(false);
    } catch {
      toast.error('Erro ao adicionar conta');
    } finally {
      setAdding(false);
    }
  };

  const toggleStatus = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    try {
      await fetch(`/api/instagram-accounts/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      setAccounts((prev: any[]) =>
        (prev ?? []).map((a: any) => (a?.id === id ? { ...(a ?? {}), status: newStatus } : a))
      );
      toast.success(newStatus === 'active' ? 'Conta ativada' : 'Conta pausada');
    } catch {
      toast.error('Erro ao alterar status');
    }
  };

  const deleteAccount = async (id: string) => {
    if (!confirm('Tem certeza que deseja remover esta conta? Todos os dados serão perdidos.')) return;
    try {
      await fetch(`/api/instagram-accounts/${id}`, { method: 'DELETE' });
      setAccounts((prev: any[]) => (prev ?? []).filter((a: any) => a?.id !== id));
      toast.success('Conta removida');
    } catch {
      toast.error('Erro ao remover conta');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Conta
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Conta Instagram</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Usuário do Instagram</Label>
                <div className="relative">
                  <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="username"
                    value={newUsername}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewUsername(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Senha do Instagram</Label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPassword(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">Senha armazenada de forma criptografada.</p>
              </div>
              <div className="space-y-2">
                <Label>Proxy (opcional)</Label>
                <Input
                  placeholder="http://user:pass@host:port"
                  value={newProxy}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewProxy(e.target.value)}
                />
              </div>
              <div className="rounded-lg bg-destructive/10 p-3">
                <p className="text-xs text-destructive flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 flex-shrink-0" />
                  A conta inicia em modo simulação (dry-run). Nenhuma ação real será executada até você desativar esse modo.
                </p>
              </div>
              <Button onClick={addAccount} className="w-full" loading={adding}>
                Adicionar Conta
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {(accounts?.length ?? 0) === 0 ? (
        <FadeIn>
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Instagram className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="font-display text-lg font-semibold">Nenhuma conta cadastrada</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Adicione sua primeira conta do Instagram para começar
              </p>
            </CardContent>
          </Card>
        </FadeIn>
      ) : (
        <Stagger className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {(accounts ?? []).map((account: any, idx: number) => {
            const status = statusMap[account?.status ?? 'inactive'] ?? statusMap.inactive;
            return (
              <StaggerItem key={account?.id ?? `acc-${idx}`}>
                <HoverLift>
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary to-pink-500 flex items-center justify-center">
                            <Instagram className="h-4 w-4 text-white" />
                          </div>
                          <div>
                            <CardTitle className="text-base">@{account?.username ?? '?'}</CardTitle>
                            <Badge variant={status?.variant}>{status?.label}</Badge>
                          </div>
                        </div>
                        {account?.dryMode && (
                          <Badge variant="outline" className="text-xs">
                            <Zap className="h-3 w-3 mr-1" /> Simulação
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-3 text-center mb-4">
                        <div className="rounded-lg bg-muted p-2">
                          <p className="text-lg font-mono font-bold">{account?.totalFollows ?? 0}</p>
                          <p className="text-xs text-muted-foreground">Follows</p>
                        </div>
                        <div className="rounded-lg bg-muted p-2">
                          <p className="text-lg font-mono font-bold">{account?.totalUnfollows ?? 0}</p>
                          <p className="text-xs text-muted-foreground">Unfollows</p>
                        </div>
                        <div className="rounded-lg bg-muted p-2">
                          <p className="text-lg font-mono font-bold">{account?._count?.targetAccounts ?? 0}</p>
                          <p className="text-xs text-muted-foreground">Alvos</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" /> Hoje: {account?.followsToday ?? 0} follows
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant={account?.status === 'active' ? 'outline' : 'default'}
                          onClick={() => toggleStatus(account?.id, account?.status)}
                          className="flex-1"
                        >
                          {account?.status === 'active' ? (
                            <><Pause className="h-3.5 w-3.5 mr-1" /> Pausar</>
                          ) : (
                            <><Play className="h-3.5 w-3.5 mr-1" /> Ativar</>
                          )}
                        </Button>
                        <Link href={`/accounts/${account?.id}`}>
                          <Button size="sm" variant="outline">
                            <Settings className="h-3.5 w-3.5" />
                          </Button>
                        </Link>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => deleteAccount(account?.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </HoverLift>
              </StaggerItem>
            );
          })}
        </Stagger>
      )}
    </div>
  );
}
