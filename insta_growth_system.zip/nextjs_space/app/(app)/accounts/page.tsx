import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import { PageHeader } from '@/components/layouts/page-header';
import { AccountsList } from './_components/accounts-list';

export const dynamic = 'force-dynamic';

export default async function AccountsPage() {
  const session = await auth();
  if (!session?.user) redirect('/login');

  const userId = (session.user as any)?.id;
  const accounts = await prisma.instagramAccount.findMany({
    where: { userId },
    include: {
      settings: true,
      _count: { select: { targetAccounts: true, followActions: true } },
    },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div>
      <PageHeader
        title="Contas Instagram"
        description="Gerencie suas contas do Instagram para crescimento automático"
      />
      <AccountsList initialAccounts={JSON.parse(JSON.stringify(accounts))} />
    </div>
  );
}
