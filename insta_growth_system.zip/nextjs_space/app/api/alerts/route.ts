export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';

export async function GET() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const userId = (session.user as any)?.id;
  const accounts = await prisma.instagramAccount.findMany({
    where: { userId },
    select: { id: true },
  });
  const accountIds = accounts.map((a: any) => a?.id).filter(Boolean);

  const alerts = await prisma.alert.findMany({
    where: { instagramAccountId: { in: accountIds } },
    include: { instagramAccount: { select: { username: true } } },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });

  return NextResponse.json(alerts);
}

export async function PATCH(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const body = await req.json();
  const { alertId } = body ?? {};

  if (alertId) {
    await prisma.alert.update({ where: { id: alertId }, data: { read: true } });
  }

  return NextResponse.json({ success: true });
}
