export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;

  const account = await prisma.instagramAccount.findFirst({
    where: { id, userId },
    include: {
      settings: true,
      targetAccounts: { orderBy: { createdAt: 'desc' } },
      whitelist: true,
      _count: { select: { followActions: true, activityLogs: true, alerts: true } },
    },
  });

  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });
  return NextResponse.json(account);
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;
  const body = await req.json();

  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const { status, dryMode, proxyUrl, settings } = body ?? {};

  const updateData: any = {};
  if (status !== undefined) updateData.status = status;
  if (dryMode !== undefined) updateData.dryMode = dryMode;
  if (proxyUrl !== undefined) updateData.proxyUrl = proxyUrl;

  const updated = await prisma.instagramAccount.update({
    where: { id },
    data: updateData,
  });

  if (settings) {
    await prisma.accountSettings.upsert({
      where: { instagramAccountId: id },
      update: settings,
      create: { instagramAccountId: id, ...settings },
    });
  }

  return NextResponse.json(updated);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;

  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  await prisma.instagramAccount.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
