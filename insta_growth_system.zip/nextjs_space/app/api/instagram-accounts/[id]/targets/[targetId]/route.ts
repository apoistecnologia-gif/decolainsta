export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string; targetId: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id, targetId } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const body = await req.json();
  const { enabled, niche } = body ?? {};

  const updateData: any = {};
  if (enabled !== undefined) updateData.enabled = enabled;
  if (niche !== undefined) updateData.niche = niche;

  const updated = await prisma.targetAccount.update({
    where: { id: targetId },
    data: updateData,
  });

  return NextResponse.json(updated);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string; targetId: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id, targetId } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  await prisma.targetAccount.delete({ where: { id: targetId } });
  return NextResponse.json({ success: true });
}
