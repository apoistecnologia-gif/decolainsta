export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const targets = await prisma.targetAccount.findMany({
    where: { instagramAccountId: id },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(targets);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const body = await req.json();
  const { username, niche } = body ?? {};

  if (!username) {
    return NextResponse.json({ error: 'Username é obrigatório' }, { status: 400 });
  }

  const cleanUsername = username.replace('@', '').trim();

  const existing = await prisma.targetAccount.findUnique({
    where: { instagramAccountId_username: { instagramAccountId: id, username: cleanUsername } },
  });
  if (existing) {
    return NextResponse.json({ error: 'Esta conta-alvo já está cadastrada' }, { status: 409 });
  }

  const target = await prisma.targetAccount.create({
    data: {
      instagramAccountId: id,
      username: cleanUsername,
      niche: niche || 'geral',
    },
  });

  return NextResponse.json(target, { status: 201 });
}
