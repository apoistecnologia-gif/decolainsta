export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const whitelist = await prisma.whitelist.findMany({
    where: { instagramAccountId: id },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(whitelist);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const { id } = await params;
  const userId = (session.user as any)?.id;
  const account = await prisma.instagramAccount.findFirst({ where: { id, userId } });
  if (!account) return NextResponse.json({ error: 'Conta não encontrada' }, { status: 404 });

  const body = await req.json();
  const { username } = body ?? {};
  if (!username) return NextResponse.json({ error: 'Username obrigatório' }, { status: 400 });

  const cleanUsername = username.replace('@', '').trim();

  const item = await prisma.whitelist.upsert({
    where: { instagramAccountId_username: { instagramAccountId: id, username: cleanUsername } },
    update: {},
    create: { instagramAccountId: id, username: cleanUsername },
  });

  return NextResponse.json(item, { status: 201 });
}
