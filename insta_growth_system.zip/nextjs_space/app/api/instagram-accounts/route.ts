export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/db';
import { encrypt } from '@/lib/encryption';

export async function GET() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const userId = (session.user as any)?.id;
  const accounts = await prisma.instagramAccount.findMany({
    where: { userId },
    include: { settings: true, _count: { select: { targetAccounts: true, followActions: true } } },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(accounts);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  try {
    const userId = (session.user as any)?.id;
    const body = await req.json();
    const { username, password, proxyUrl } = body ?? {};

    if (!username || !password) {
      return NextResponse.json({ error: 'Usuário e senha do Instagram são obrigatórios' }, { status: 400 });
    }

    const existing = await prisma.instagramAccount.findUnique({
      where: { userId_username: { userId, username } },
    });
    if (existing) {
      return NextResponse.json({ error: 'Esta conta já está cadastrada' }, { status: 409 });
    }

    const encryptedPassword = encrypt(password);

    const account = await prisma.instagramAccount.create({
      data: {
        userId,
        username,
        encryptedPassword,
        proxyUrl: proxyUrl || null,
        status: 'inactive',
        dryMode: true,
        settings: {
          create: {},
        },
      },
      include: { settings: true },
    });

    return NextResponse.json(account, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message ?? 'Erro interno' }, { status: 500 });
  }
}
