import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Hidden test account (required)
  const testPassword = await bcrypt.hash('h$Xxl5drxW', 12);
  await prisma.user.upsert({
    where: { email: 'abacus-278e6458@example.com' },
    update: {},
    create: {
      email: 'abacus-278e6458@example.com',
      password: testPassword,
      name: 'Admin',
      role: 'admin',
    },
  });

  console.log('Seed completed successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
